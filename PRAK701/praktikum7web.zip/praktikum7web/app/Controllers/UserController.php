<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class UserController extends BaseController
{
    //fungsi index untuk mengembalikan tampilan (view) dengan nama 'login'
    public function index()
    {
        return view('login');
    }

    //fungsi login untuk menangani proses login user.
    public function login()
    {
        $user = new UserModel();
        //method getPost() untuk menangkap data yang dikirim melalui POST request.
        $username = $this->request->getPost('username');
        $pw = $this->request->getPost('password');
        //method where() untuk mencari data pengguna berasarkan username atau email.
        $dataUser = $user->where(['username' => $username])->orWhere(['email' => $username])->first();
        if ($dataUser) {
            //Pengkondisian dimana method password_verify() akan memverifikasi password apakah sudah benar, jika sudah maka user akan diarahkan ke halaman 'buku'.
            if (password_verify($pw, $dataUser['password'])) {
                session()->set([
                    'username' => $dataUser['username'],
                    'email' => $dataUser['email'],
                    'logged_in' => true
                ]);
                
                //Jika password salah, maka akan ada alert Password salah.
                return redirect()->to(base_url('buku'));
            } else {
                session()->setFlashdata('pesan', 'Password salah');
                return redirect()->to(base_url('login'));
            }
        } else {
            //Jika uname atau email salah, maka akan ada alert Username atau email tidak ditemukan.
            session()->setFlashdata('pesan', 'Username atau email tidak ditemukan');
            return redirect()->to(base_url('login'));
        }
    }

    //fungsi logout() yang menggunakan method destroy() untuk mengakhiri data sesi user dan mengarahkannya kembali ke halaman login.
    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}
