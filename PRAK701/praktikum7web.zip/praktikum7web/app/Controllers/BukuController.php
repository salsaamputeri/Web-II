<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BukuModel;

class BukuController extends BaseController
{
    //fungsi index() untuk menampilkan halaman indeks yang menampilkan daftar buku. 
    public function index()
    {
        //method findAll() untuk mengambil seluruh data buku dan ditampilkan pada buku/index.
        return view('buku/index', [
            'buku' => (new BukuModel())->findAll()
        ]);
    }

    //fungsi create() untuk menampilkan halaman formulir pembuatan buku baru. 
    public function create()
    {
        return view('buku/create');
    }

    //fungsi store() untuk menyimpan data buku yang dikirimkan melalui formulir create.
    public function store()
    {
        $buku = new BukuModel();

        //method getPost() untuk mengambil data buku dar permintaan lalu dimasukkan ke tabel dengan method insert().
        $buku->insert([
            'judul' => $this->request->getPost('judul'),
            'penulis' => $this->request->getPost('penulis'),
            'penerbit' => $this->request->getPost('penerbit'),
            'tahun_terbit' => $this->request->getPost('tahun_terbit'),
        ]);

        //mengarahkan user kembali ke halaman indeks buku.
        return redirect()->to('/buku');
    }

    //fungsi edit() untuk menampilkan halaman formulir pengeditan buku berdasarkan ID buku yang diberikan.
    public function edit($id)
    {
        //method find($id) untuk mencari data buku dengan id.
        return view('buku/edit', [
            'buku' => (new BukuModel())->find($id)
        ]);
    }

    //fungsi update() untuk mengupdate data buku berdasarkan ID buku yang diberikan.
    public function update($id)
    {
        $buku = new BukuModel();

        //method getPost() untuk mengambil data buku dar permintaan lalu dimasukkan ke tabel dengan method update().
        $buku->update($id, [
            'judul' => $this->request->getPost('judul'),
            'penulis' => $this->request->getPost('penulis'),
            'penerbit' => $this->request->getPost('penerbit'),
            'tahun_terbit' => $this->request->getPost('tahun_terbit'),
        ]);

        //mengarahkan user kembali ke halaman indeks buku.
        return redirect()->to('/buku');
    }

    //fungsi delete() untuk menghapus data buku berdasarkan ID buku yang diberikan.
    public function delete($id)
    {
        $buku = new BukuModel();

        $buku->delete($id);

        return redirect()->to('/buku');
    }

    
}
