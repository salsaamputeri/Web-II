<?php

namespace App\Database\Seeds;

//Import class Seeder untuk membuat seeder tertentu
use CodeIgniter\Database\Seeder;
//Import class BukuModel untuk diisi data pada tabel buku di database

//Deklarasi class ekstensi Seeder, yang akan mengisi Class user dengan data awal untuk dimasukkan ke dalam database.
class UserSeeder extends Seeder
{
    public function run()
    {
        $this->db->table('user')->insert([
            'username' => 'admin',
            'email' => 'admin@gmail.com',
            'password' => password_hash('12345', PASSWORD_DEFAULT),
        ]);
    }
}