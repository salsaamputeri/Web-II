<!DOCTYPE html>
<html>

<head>
    <title>Biodata</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', Arial, sans-serif;
        }

        body {
            background-color: #fff9e6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #f6f8ff;
            border-radius: 20px;
            padding: 30px;
            box-shadow: -6px 2px 20px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 10px;
            overflow: hidden;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            background-color: #fff;
            border-top: 1px solid #ddd;
        }

        th:first-child,
        td:first-child {
            border-top-left-radius: 10px;
        }

        th:last-child,
        td:last-child {
            border-top-right-radius: 10px;
        }

        th {
            color: #333;
            background-color: #f6f8ff;
        }

        .profile-img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center;
            box-shadow: -6px 2px 20px 8px rgba(0, 0, 0, 0.1);
            margin: 0 auto 20px;
            display: block;
        }

        .btn-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .btn-container button {
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            background-color: #81c1ff;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .btn-container button:hover {
            background-color: #62a7ff;
            transform: translateX(5px);
        }

        .btn-container button:active {
            transform: translateY(2px);
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Biodata</h1>

        <table>
            <tr>
                <td rowspan="8"><img src="<?= base_url('images/' . $foto) ?>" class="profile-img"></td>
                <th>Nama Lengkap</th>
                <td><?= $nama; ?></td>
            </tr>
            <tr>
                <th>NIM</th>
                <td><?= $nim; ?></td>
            </tr>
            <tr>
                <th>Asal Prodi</th>
                <td><?= $prodi; ?></td>
            </tr>
            <tr>
                <th>Hobi</th>
                <td><?= $hobi; ?></td>
            </tr>
            <tr>
                <th>Skill</th>
                <td><?= $skill; ?></td>
            </tr>
        </table>
    </div>
    <div class="btn-container">
        <form action="/home/index">
            <button>Beranda</button>
        </form>
    </div>

</body>

</html>
