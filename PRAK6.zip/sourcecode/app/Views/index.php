<!DOCTYPE html>
<html>

<head>
    <title>PRAK601</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', Arial, sans-serif;
        }

        body {
            background-color: #c1e1ff;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f6f8ff;
            border-radius: 20px;
            box-shadow: -6px 2px 20px 8px rgba(0, 0, 0, 0.1);
            margin-top: 100px;
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
            background-color: #ffffc7;
        }

        th,
        td {
            padding: 10px;
            text-align: center;
            background-color: #ffffc7;
        }

        th {
            width: 30%;
            color: #333;
        }

        td {
            color: #333;
        }

        .btn-container {
            display: flex;
            justify-content: flex-end;
        }

        .btn-container button {
            margin-top: 10px;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            background-color: #81c1ff;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            transition: background-color 0.3s ease;
            position: relative;
            overflow: hidden;
            animation: moveButton 0.5s ease-in-out;
        }

        .btn-container button:hover {
            background-color: #62a7ff;
            animation: none;
        }

        @keyframes moveButton {
            0% {
                transform: translateX(0);
            }
            50% {
                transform: translateX(5px);
            }
            100% {
                transform: translateX(0);
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1>Profil Mahasiswa</h1>
        <table>
            <tr>
                <th>Nama</th>
                <td>
                    <?= $nama ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim ?>
                </td>
            </tr>
        </table>
        <div class="btn-container">
            <form action="/home/biodata">
                <button>
                    Biodata
                </button>
            </form>
        </div>
    </div>
</body>

</html>