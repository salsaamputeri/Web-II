<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelMahasiswa extends Model
{
    protected $nama = "Salsa Maulidina Puteri";
    protected $foto = "Foto.png";
    protected $nim = "2110817220003";
    protected $prodi = "Teknologi Informasi";
    protected $hobi = "Memasak";
    protected $skill = "Membuat Makanan";


    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function gethobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}