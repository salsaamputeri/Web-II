<?php

namespace App\Controllers;

use App\Models\ModelMahasiswa;

class Home extends BaseController
{
    public function index()
    {
        $mahasiswa = new ModelMahasiswa();
        return view('index', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
        ]);
    }
    public function biodata()
    {
        $mahasiswa = new ModelMahasiswa();
        return view('biodata', [
            "nama" => $mahasiswa->getNama(),
            "foto" => $mahasiswa->getFoto(),
            "nim" => $mahasiswa->getNim(),
            "prodi" => $mahasiswa->getProdi(),
            "hobi" => $mahasiswa->gethobi(),
            "skill" => $mahasiswa->getSkill()
        ]);
    }
}